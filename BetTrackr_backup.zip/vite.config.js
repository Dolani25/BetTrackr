
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
<<<<<<< HEAD
  server: {
    allowedHosts: true,
=======
server: { allowedHosts: true, } ,
  resolve: {
    alias: {
      // Directly specify the package name
      'react-router-dom': 'react-router-dom',
    },
>>>>>>> a1de3a8b0991584258d88622ef79fbd1229a7796
  },
});
